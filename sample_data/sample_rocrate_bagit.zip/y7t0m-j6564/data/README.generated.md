# DATASET NAME: [RO-Crate import: BagIt package with files] Kvalita ovzduší ve středních Čechách 2024 – Komplexní analýza koncentrací znečišťujících látek z automatizovaných měřicích stanic provozovaných ČHMÚ včetně prostorového rozložení a časových trendů

> This README was **generated automatically** from the metadata of the dataset in the repository on
> 2026-11-07 (https://127.0.0.1:5000/datasets/records/y7t0m-j6564). Sections the metadata has no information for are left out,
> and even metadata the record has may be missing from this README - for the complete metadata, see the
> record in the repository: [https://127.0.0.1:5000/datasets/records/y7t0m-j6564](https://127.0.0.1:5000/datasets/records/y7t0m-j6564).

## BASIC INFORMATION

Author(s):

- Šimek, Miroslav, ORCID: [0000-0003-0852-6632](https://orcid.org/0000-0003-0852-6632) (CESNET z.s.p.o.)
- Novák, Jan (Univerzita Karlova)
- Dvořáková, Marie (ČHMÚ)
- Procházka, Tomáš (CESNET z.s.p.o.)

- Dataset license: [Creative Commons Attribution 4.0 International](https://creativecommons.org/licenses/by/4.0/)
- Dataset version: 1.0.23
- README version: generated from the repository metadata on 2026-11-07
- PID: [https://127.0.0.1:5000/datasets/records/y7t0m-j6564](https://127.0.0.1:5000/datasets/records/y7t0m-j6564)

---

## DESCRIPTION

### Brief Description

Tato datová sada obsahuje měření kvality ovzduší ve středních Čechách v roce 2024. Data byla shromážděna z automatizovaných měřicích stanic provozovaných Českým hydrometeorologickým ústavem (ČHMÚ) a zahrnují koncentrace znečišťujících látek jako PM10, PM2.5, oxid dusičitý (NO₂), oxid siřičitý (SO₂) a přízemní ozón (O₃). Měření probíhala kontinuálně po celý rok 2024 s hodinovým rozlišením. Datová sada je určena pro výzkumné účely v oblasti ochrany ovzduší a environmentální analýzy.

This dataset contains air quality measurements from the Central Bohemian Region in 2024. The data was collected from automated monitoring stations operated by the Czech Hydrometeorological Institute (CHMI) and includes concentrations of pollutants such as PM10, PM2.5, nitrogen dioxide (NO₂), sulfur dioxide (SO₂), and ground-level ozone (O₃). Measurements were taken continuously throughout 2024 with hourly resolution. The dataset is intended for research purposes in the field of air quality protection and environmental analysis.

---

## DATASET/COLLECTION CONTENTS

### Directory Structure

- [air_quality_stations_2024.csv](https://127.0.0.1:5000/api/datasets/y7t0m-j6564/files/air_quality_stations_2024.csv/content) (364 Bytes, text/csv)
- [measurement_methodology.txt](https://127.0.0.1:5000/api/datasets/y7t0m-j6564/files/measurement_methodology.txt/content) (268 Bytes, text/plain)

---

## METHODOLOGY-PROVENANCE

### Collection/Creation of Data

- Collection date: 2024-01-01
- Collection location: Středočeský kraj

---

## REUSE

### License and Terms of Use

- [Creative Commons Attribution 4.0 International](https://creativecommons.org/licenses/by/4.0/)

---

## PROPOSED CITATION

Šimek, Miroslav; Novák, Jan; Dvořáková, Marie; Procházka, Tomáš (2025): [RO-Crate import: BagIt package with files] Kvalita ovzduší ve středních Čechách 2024 – Komplexní analýza koncentrací znečišťujících látek z automatizovaných měřicích stanic provozovaných ČHMÚ včetně prostorového rozložení a časových trendů. Český hydrometeorologický ústav ve spolupráci s CESNET z.s.p.o. a Univerzitou Karlovou. (Dataset). https://127.0.0.1:5000/datasets/records/y7t0m-j6564. Version 1.0.23.

---

## ACKNOWLEDGEMENTS

- Funded by Grantová agentura České republiky, award https://doi.org/award-identifier

- Krejčí, Petr (CESNET z.s.p.o.) - Other
- Svobodová, Eva (Univerzita Karlova) - Other
- Horák, Martin (ČHMÚ) - Other
- Veselá, Lucie (Masarykova univerzita) - Other
- Černý, Jiří (Akademie věd ČR) - Other

This README was based on the template/examples authored by the **[Collective of Data Stewards of the Czech Data Stewards Community](https://github.com/Czech-Data-Steward-Community/README_FILES/blob/main/Collective_datastewards.md)** and is licensed under a [Creative Commons Attribution 4.0 International License (CC BY 4.0)](https://creativecommons.org/licenses/by/4.0/).

---

## README FILE CHANGE HISTORY

`2026-11-07` Generated from the repository metadata of dataset version 1.0.23.
